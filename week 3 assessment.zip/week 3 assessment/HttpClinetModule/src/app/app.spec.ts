import { describe, it, expect } from 'vitest';

describe('App placeholder', () => {
  it('sanity check', () => {
    expect(true).toBe(true);
  });
});
