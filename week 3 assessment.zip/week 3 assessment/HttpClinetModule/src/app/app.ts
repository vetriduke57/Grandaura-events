import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ApiService } from './api';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule],
  template: `
    <h1>Hello, HttpClientModule</h1>
    <ul>
      <li *ngFor="let p of posts">{{ p.title }}</li>
    </ul>
  `,
  styles: []
})
export class App implements OnInit {
  posts: any[] = [];

  constructor(private api: ApiService) {}

  ngOnInit(): void {
    this.api.getPosts().subscribe((data: any) => {
      this.posts = data;
      console.log(data);
    });
  }
}
