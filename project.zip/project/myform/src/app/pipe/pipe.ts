import { Component } from '@angular/core';

@Component({
  selector: 'app-pipe',
  templateUrl: './pipe.html',
  styleUrls: ['./pipe.css'],
})
export class Pipe {
  str: string = 'Hello Everyone';
  amount: number = 5000;
  today: Date = new Date();
  emp = {
    id: 101,
    name: 'Anand',
    role: 'Angular Developer',
    salary: 60000,
  };
}
