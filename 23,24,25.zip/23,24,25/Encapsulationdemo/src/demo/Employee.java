package demo;

public class Employee {

    // Step 1: Make variables private
    private String name;
    private double salary;

    // Step 2: Create Getter for name
    public String getName() {
        return name;
    }

    // Step 3: Create Setter for name
    public void setName(String name) {
        this.name = name;
    }

    // Step 4: Create Getter for salary
    public double getSalary() {
        return salary;
    }

    // Step 5: Create Setter for salary
    public void setSalary(double salary) {
        if (salary > 0) {
            this.salary = salary;
        } else {
            System.out.println("Salary must be positive!");
        }
    }
}