package demo;

public class Main {

    public static void main(String[] args) {

        // Create object of Employee
        Employee emp = new Employee();

        // Access data using setter
        emp.setName("John");
        emp.setSalary(50000);

        // Access data using getter
        System.out.println("Employee Name: " + emp.getName());
        System.out.println("Employee Salary: " + emp.getSalary());
    }
}
