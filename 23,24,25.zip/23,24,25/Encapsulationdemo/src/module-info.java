/**
 * 
 */
/**
 * 
 */
module Encapsulationdemo {
}