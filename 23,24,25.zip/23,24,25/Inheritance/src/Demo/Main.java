package Demo;

public class Main {

    public static void main(String[] args) {

        Admin admin = new Admin();
        admin.login();
        admin.manageUsers();
    }
}