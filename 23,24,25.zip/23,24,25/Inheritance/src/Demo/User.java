package Demo;

public class User {

    protected String name;

    public void login() {
        System.out.println("User logged in");
    }
}