package Demo;

public class Admin extends User {

    public void manageUsers() {
        System.out.println("Admin managing users");
    }
}