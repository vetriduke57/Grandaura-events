package com.example.demo.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.modelentity.Employee;
import com.example.demo.services.MyServices;

@RestController
public class MyController {

    @Autowired
    private MyServices services;

    @GetMapping("/employees")
    public List<Employee> getAllEmployee() {
        return services.getAllEmployee();
    }

    @GetMapping("/employees/{id}")
    public Employee getEmployeeById(@PathVariable int id) {
        return services.getEmployeeById(id);
    }

    @PostMapping("/employees")
    public String addEmployee(@RequestBody Employee employee) {
        return services.addEmployee(employee);
    }

    @PutMapping("/employees/{id}")
    public String updateEmployee(@PathVariable int id,
                                 @RequestBody Employee updatedEmployee) {
        return services.updateEmployee(id, updatedEmployee);
    }

    @DeleteMapping("/employees/{id}")
    public String deleteEmployee(@PathVariable int id) {
        return services.deleteEmployee(id);
    }

    @DeleteMapping("/employees")
    public String deleteAllEmployee() {
    	return services.deleteAllEmployees();
    }
}
