package com.example.demo.modelentity;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity




public class Employee {
	@Id
	
	
	private int id;
	private String name;
	private int age;
	private int salary;
	private String design;
	
	public Employee() {
	
	}
	public Employee (int id, String name, int age, int salary, String design) {
		
		this.id=id;
		this.name=name;
		this.age=age;
		this.salary=salary;
		this.design=design;
	}
	public int getid() {
		return id;
		
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public int getSalary() {
		return salary;
	}
	public void setSalary(int salary) {
		this.salary = salary;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDesign() {
		return design;
	}
	public void setDesign(String design) {
		this.design = design;
	}
}
	
