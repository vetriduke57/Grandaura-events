package demo;

public class mainclass {

	public static void main(String[] args) {

        Engine engine = new Engine();   // create dependency
        Car car = new Car();            // create object

        car.setEngine(engine);          // inject dependency
        car.drive();
    }
}




    