package com.example.demo;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import com.example.demo.entity.Employee;
import com.example.demo.repository.EmployeeRepository;

import jakarta.validation.Valid;

@Controller
public class LoginController {

    @Autowired
    private EmployeeRepository repository;

    @GetMapping("/")
    public String showLogin(Model model) {
        model.addAttribute("employee", new Employee());
        return "login";
    }

    @PostMapping("/login")
    public String login(@Validated @ModelAttribute("employee") Employee employee,
                        BindingResult result,
                        Model model) {

        if(result.hasErrors()) {
            return "login";
        }

        Employee emp = repository.findByUsername(employee.getUsername());

        if(emp != null && emp.getPassword().equals(employee.getPassword())) {
            model.addAttribute("username", emp.getUsername());
            return "welcome";
        }

        model.addAttribute("error", "Invalid Username or Password");
        return "login";
    }
}