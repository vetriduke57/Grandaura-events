import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Bravo } from './bravo';

describe('Bravo', () => {
  let component: Bravo;
  let fixture: ComponentFixture<Bravo>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [Bravo]
    })
    .compileComponents();

    fixture = TestBed.createComponent(Bravo);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
