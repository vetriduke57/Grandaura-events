import { Component } from '@angular/core';

@Component({
  selector: 'app-bravo',
  imports: [],
  templateUrl: './bravo.html',
  styleUrl: './bravo.css',
})
export class Bravo {

}
