import { Component, signal } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { Bravo } from './bravo/bravo';

@Component({
  selector: 'app-root',
  imports: [RouterOutlet,Bravo],
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class App {
  protected readonly title = signal('alph');
}
