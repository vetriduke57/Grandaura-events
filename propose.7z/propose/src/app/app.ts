import { Component, signal } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { Teddy } from './teddy/teddy';

@Component({
  selector: 'app-root',
  imports: [RouterOutlet,Teddy],
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class App {
  protected readonly title = signal('propose');
}
