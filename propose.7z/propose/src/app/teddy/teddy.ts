import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-teddy',
  imports: [FormsModule],
  templateUrl: './teddy.html',
  styleUrl: './teddy.css',
})
export class Teddy {
  //interpolation
name="call sign patty";

  //property bindinging
isDisabled=false;

  //enable binding
enablebutton(){
  this.isDisabled=true;
}

  //two way binding
  username='';
  showalert(){
  alert("Access denied"+ this.username)
}
}
