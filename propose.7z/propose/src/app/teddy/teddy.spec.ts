import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Teddy } from './teddy';

describe('Teddy', () => {
  let component: Teddy;
  let fixture: ComponentFixture<Teddy>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [Teddy]
    })
    .compileComponents();

    fixture = TestBed.createComponent(Teddy);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
