import { bootstrapApplication } from '@angular/platform-browser';
import { Chuckels } from './app/chuckels/chuckels';

bootstrapApplication(Chuckels)
  .catch(err => console.error(err));
