import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class Peace {

  private storageKey = 'flirtbox-chat';

  getMessages(): any[] {
    const data = localStorage.getItem(this.storageKey);
    return data ? JSON.parse(data) : [];
  }

  sendMessage(message: any) {
    const messages = this.getMessages();
    messages.push(message);
    localStorage.setItem(this.storageKey, JSON.stringify(messages));
  }

  clearChat() {
    localStorage.removeItem(this.storageKey);
  }
}
