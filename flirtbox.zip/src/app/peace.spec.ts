import { TestBed } from '@angular/core/testing';

import { Peace } from './peace';

describe('Peace', () => {
  let service: Peace;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(Peace);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
