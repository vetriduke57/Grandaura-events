import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Peace } from '../peace';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './chuckels.html',
  styleUrls: ['./chuckels.css']
})
export class Chuckels implements OnInit {

  users = ['Angel', 'Romeo', 'Bella'];
  currentUser = 'Angel';
  messageText = '';
  messages: any[] = [];

  constructor(private peace: Peace) {}

  ngOnInit() {
    this.loadMessages();

    window.addEventListener('storage', () => {
      this.loadMessages();
    });
  }

  loadMessages() {
    this.messages = this.peace.getMessages();
  }

  send() {
    if (!this.messageText.trim()) return;

    const message = {
      sender: this.currentUser,
      text: this.messageText,
      time: new Date().toLocaleTimeString()
    };

    this.peace.sendMessage(message);
    this.messageText = '';
    this.loadMessages();
  }
}
