import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Chuckels } from './chuckels';

describe('Chuckels', () => {
  let component: Chuckels;
  let fixture: ComponentFixture<Chuckels>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [Chuckels]
    })
    .compileComponents();

    fixture = TestBed.createComponent(Chuckels);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
