package com.example.demo;

public class model {
	public static void main(String[] args) {
		try {
	         System.out.println("apple");
	         System.out.println("ball");
	         System.out.println("cat");
	         System.out.println(10/0);
	         System.out.println("dog");
	         System.out.println("elephant");	
		}
		catch(exception e) {
			System.out.println("fox"+e);
		}
	System.out.println("vfhadvsfhjadvfjhadvf");
	}
	

}
