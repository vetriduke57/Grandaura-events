package com.example.demo;

public class model3 {
public static void main(String[] args) {
	try {
		int a[]= {10,20,30};
		System.out.println(a[0]);
		System.out.println(a[1]);
		System.out.println(a[2]);
		System.out.println(a[3]);
	} catch (exception e) {
		System.out.println("vfcgdhjvhjasdvhvc");
	}
	System.out.println("dsbkdbsvkjdfbvkjfkdsb");
}
}
