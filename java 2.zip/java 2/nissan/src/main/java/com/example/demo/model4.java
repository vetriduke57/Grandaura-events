package com.example.demo;

public class model4 {
	public static void main(String[] args) {
		try {
			int a[]= {10,20,30};
			System.out.println(a[0]);
			System.out.println(a[1]);
			System.out.println(a[2]);
			System.out.println(a[3]);
			System.out.println(10/2);
		}
		catch(ArithmeticException e) {
			System.out.println("hdvvf"+ e);
				
			}
		 catch(ArrayIndexOutOfBoundsException e1) {
			 System.out.println("hdvvf"+ e1);
		 }
		catch(Exception e) {
			 System.out.println("hdvvf"+ e);
		}
		System.out.println("gsdhfjhfjdguyAGDJHFHDGF");
	}

}


