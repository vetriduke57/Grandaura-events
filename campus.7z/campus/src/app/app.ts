import { Component, signal } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { Puma } from './puma/puma';
import { Redtape } from './redtape/redtape';

@Component({
  selector: 'app-root',
  imports: [RouterOutlet,Puma, Redtape],
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class App {
  protected readonly title = signal('campus');
}
