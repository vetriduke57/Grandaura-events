import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Puma } from './puma';

describe('Puma', () => {
  let component: Puma;
  let fixture: ComponentFixture<Puma>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [Puma]
    })
    .compileComponents();

    fixture = TestBed.createComponent(Puma);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
