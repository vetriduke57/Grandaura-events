import { Component } from '@angular/core';

@Component({
  selector: 'app-puma',
  imports: [],
  templateUrl: './puma.html',
  styleUrl: './puma.css',
})
export class Puma {
  name:string ="vetri";
  course:string ="angular training";
  fees:string ="1000";

}
