import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';

@Component({
  selector: 'app-redtape',
  imports: [CommonModule],
  templateUrl: './redtape.html',
  styleUrl: './redtape.css',
})
export class Redtape {
   // ====== ngIf ======
  isLoggedIn: boolean = false;

  // ====== ngFor ======
  courses: string[] = ['Angular', 'React', 'Vue', 'Node'];

  // ====== ngSwitch ======
  role: string = 'admin';

  // ====== Methods ======
  login() {
    this.isLoggedIn = true;
  }

  logout() {
    this.isLoggedIn = false;
  }

  setRole(newRole: string) {
    this.role = newRole;
  }


}
