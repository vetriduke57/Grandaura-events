package com.tracker.formidables.model;

import jakarta.persistence.*;
import java.time.LocalDate;
import java.util.List;

@Entity
@Table(name = "daily_trackers")
public class DailyTracker {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private LocalDate trackingDate;

    // Hours tracked
    private Double studyHours;
    private Double workHours;
    private Double socialHours;
    private Double phoneHours;

    // Health
    private Integer exerciseMins;
    private Double water;

    // Reflections
    @Column(columnDefinition = "TEXT")
    private String notes;

    // Score
    private Integer score;

    // Fetch lists eagerly or handle bidirectional relationships
    @OneToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER, orphanRemoval = true)
    @JoinColumn(name = "tracker_id")
    private List<TaskItem> upscTasks;

    // To prevent multiple bag fetching exceptions, we'll use lazy for others, but
    // for simplicity here we keep it basic
    // For production, consider using @ElementCollection or ensuring Set is used
    // instead of List to avoid MultipleBagFetchException.
    // Using simple approach below: EAGER on one, LAZY/Transactional on others, or
    // better: switch to Set or Json

    // Changing to @ElementCollection for simplicity of lists in Spring Data JPA
    // without causing Cartesian Product issues
    @ElementCollection
    @CollectionTable(name = "ssc_tasks", joinColumns = @JoinColumn(name = "tracker_id"))
    private List<EmbeddableTask> sscTasks;

    @ElementCollection
    @CollectionTable(name = "tnpsc_tasks", joinColumns = @JoinColumn(name = "tracker_id"))
    private List<EmbeddableTask> tnpscTasks;

    @ElementCollection
    @CollectionTable(name = "upsc_tasks_list", joinColumns = @JoinColumn(name = "tracker_id"))
    private List<EmbeddableTask> upscTasksList;

    public DailyTracker() {
        this.trackingDate = LocalDate.now();
    }

    // Getters and Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public LocalDate getTrackingDate() {
        return trackingDate;
    }

    public void setTrackingDate(LocalDate trackingDate) {
        this.trackingDate = trackingDate;
    }

    public Double getStudyHours() {
        return studyHours;
    }

    public void setStudyHours(Double studyHours) {
        this.studyHours = studyHours;
    }

    public Double getWorkHours() {
        return workHours;
    }

    public void setWorkHours(Double workHours) {
        this.workHours = workHours;
    }

    public Double getSocialHours() {
        return socialHours;
    }

    public void setSocialHours(Double socialHours) {
        this.socialHours = socialHours;
    }

    public Double getPhoneHours() {
        return phoneHours;
    }

    public void setPhoneHours(Double phoneHours) {
        this.phoneHours = phoneHours;
    }

    public Integer getExerciseMins() {
        return exerciseMins;
    }

    public void setExerciseMins(Integer exerciseMins) {
        this.exerciseMins = exerciseMins;
    }

    public Double getWater() {
        return water;
    }

    public void setWater(Double water) {
        this.water = water;
    }

    public String getNotes() {
        return notes;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }

    public Integer getScore() {
        return score;
    }

    public void setScore(Integer score) {
        this.score = score;
    }

    public List<EmbeddableTask> getSscTasks() {
        return sscTasks;
    }

    public void setSscTasks(List<EmbeddableTask> sscTasks) {
        this.sscTasks = sscTasks;
    }

    public List<EmbeddableTask> getTnpscTasks() {
        return tnpscTasks;
    }

    public void setTnpscTasks(List<EmbeddableTask> tnpscTasks) {
        this.tnpscTasks = tnpscTasks;
    }

    public List<EmbeddableTask> getUpscTasksList() {
        return upscTasksList;
    }

    public void setUpscTasksList(List<EmbeddableTask> upscTasksList) {
        this.upscTasksList = upscTasksList;
    }
}
