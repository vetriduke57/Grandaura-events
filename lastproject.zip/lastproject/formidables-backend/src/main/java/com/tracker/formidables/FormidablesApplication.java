package com.tracker.formidables;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FormidablesApplication {

	public static void main(String[] args) {
		SpringApplication.run(FormidablesApplication.class, args);
	}
}
