package com.tracker.formidables.repository;

import com.tracker.formidables.model.DailyTracker;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface DailyTrackerRepository extends JpaRepository<DailyTracker, Long> {
}
