package com.tracker.formidables.controller;

import com.tracker.formidables.model.DailyTracker;
import com.tracker.formidables.repository.DailyTrackerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;

@RestController
@RequestMapping("/api/trackers")
@CrossOrigin(origins = "*")
public class DailyTrackerController {

    @Autowired
    private DailyTrackerRepository repository;

    @GetMapping
    public List<DailyTracker> getAllTrackers() {
        return repository.findAll();
    }

    @PostMapping
    public ResponseEntity<DailyTracker> saveTracker(@RequestBody DailyTracker tracker) {
        if (tracker.getTrackingDate() == null) {
            tracker.setTrackingDate(LocalDate.now());
        }
        DailyTracker saved = repository.save(tracker);
        return ResponseEntity.ok(saved);
    }
}
