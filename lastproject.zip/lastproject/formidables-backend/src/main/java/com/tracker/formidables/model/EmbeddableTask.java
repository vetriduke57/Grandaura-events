package com.tracker.formidables.model;

import jakarta.persistence.Embeddable;

@Embeddable
public class EmbeddableTask {

    private String text;
    private Boolean done;

    public EmbeddableTask() {
    }

    public EmbeddableTask(String text, Boolean done) {
        this.text = text;
        this.done = done;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public Boolean getDone() {
        return done;
    }

    public void setDone(Boolean done) {
        this.done = done;
    }
}
