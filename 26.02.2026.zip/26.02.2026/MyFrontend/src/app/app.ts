import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { EmployeeService } from './services/employee-service';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './app.html',
  styleUrls: ['./app.css']
})
export class App implements OnInit {

  employees = signal<any[]>([]);

  constructor(private empService: EmployeeService) {}

  ngOnInit() {
    this.empService.getEmployees().subscribe({
      next: (data) => {
        console.log('DATA:', data);
        this.employees.set(data);   // 🔥 important
      },
      error: (err) => {
        console.error('ERROR:', err);
      }
    });
  }
}
