package inheritance;


// method overloading/ method overriding

//same name of the method with  diffi in same class	
//same nan of  a method with same parameter in ssub classs

class ennore
{
void m1()
{
	System.out.println("i am a fool");
}
}

public class delta extends ennore{

public static void main(String[] args) {
	delta  xy = new delta();
xy.m1();


}
}
