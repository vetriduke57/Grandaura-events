/**
 * 
 */
package inheritance;

/**
 * 
 */
public class Encaps {
			  int b=8;
			   void m2(int b) 
			   {
				   System.out.println("hello "+b);
				   System.out.println("hello "+this.b);
			//	   System.out.println("hello "+a);
			   }
		public static void main(String[] args) {
			Encaps  xy = new Encaps();
			xy.m2(3);
		}
		}

	