package inheritance;



// method overloading/ method overriding

//same name of the method with  diffi in same class	
//same nan of  a method with same parameter in ssub classs

abstract class Abcd
{
abstract  void m1() ;
}


public class bravo extends Abcd {
void m1()
{
	System.out.println("method m1");
}

public static void main(String[] args) {
	bravo  xy = new bravo();
xy.m1();

}
}