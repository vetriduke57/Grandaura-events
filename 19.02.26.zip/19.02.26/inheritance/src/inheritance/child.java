package inheritance;

class GrandFather {
	void sugar()
	{
		System.out.println("i am having sugar");
	}
}

class father extends GrandFather {
	void bp()
	{

		System.out.println("I am having BP");
	}
}

public class child extends father {
	

	
public static void main(String[] args) {
	child  cc = new child();
	cc.bp();
    cc.sugar();
}

}

//  OOPS
// inheriance , encpsulation , polymorphism, abstraction
