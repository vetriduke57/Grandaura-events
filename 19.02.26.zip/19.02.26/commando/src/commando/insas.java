package commando;

public class insas {

	public insas() {
		// TODO Auto-generated constructor stub
	}

}
