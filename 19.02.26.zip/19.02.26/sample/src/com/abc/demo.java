package com.abc;

public class demo {
	public demo() {
		// TODO Auto-generated constructor stub
	System.out.println("never lie");
	}
	

	void m1() {
		System.out.println("I am a Wingman of Maverick");
	}
	void m2() {
		System.out.println("duck is cute but mental sometimes"+  (57+16));
	}
	
	void triangle(int l, int b) {
		int area = (l * b) / 2; 
		System.out.println("Area of triangle: " + area); }
	
	public static void main(String[] args) {
		demo vv = new demo();
		vv .m1();
		vv .m2();
		vv. triangle (20, 5);
	}
}

